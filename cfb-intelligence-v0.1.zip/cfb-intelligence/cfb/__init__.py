"""CFB Intelligence prediction package."""
